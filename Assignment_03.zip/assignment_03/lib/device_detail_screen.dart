import 'package:flutter/material.dart';
import '../models/device.dart';


class DeviceDetailsScreen extends StatefulWidget {
  final Device device;
  const DeviceDetailsScreen({super.key, required this.device});


  @override
  State<DeviceDetailsScreen> createState() => _DeviceDetailsScreenState();
}


class _DeviceDetailsScreenState extends State<DeviceDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.device.name)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.settings, size: 120),
            const SizedBox(height: 20),
            Text("Status: ${widget.device.isOn ? "ON" : "OFF"}"),
            const SizedBox(height: 20),


            if (widget.device.type == "Light" || widget.device.type == "Fan")
              Slider(
                value: widget.device.value,
                min: 0,
                max: 100,
                onChanged: (v) {
                  setState(() {
                    widget.device.value = v;
                  });
                },
              )
            else
              const Text("No adjustable controls for this device"),
          ],
        ),
      ),
    );
  }
}