import 'package:flutter/material.dart';
import 'models/device.dart';

class DeviceCard extends StatelessWidget {
  final Device device;
  final VoidCallback onToggle;
  final VoidCallback onTap;

  const DeviceCard({
    super.key,
    required this.device,
    required this.onToggle,
    required this.onTap,
  });

  // Map device type to asset image
  String getDeviceImage(String type) {
    switch (type) {
      case "Light":
        return "asset/bulb.jpeg";
      case "Fan":
        return "asset/fan.jpeg";
      case "AC":
        return "asset/ac.jpeg";
      case "Camera":
        return "asset/camera.jpeg";
      default:
        return "asset/unknown.png";
    }
  }
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 10,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Device image
            Image.asset(
              getDeviceImage(device.type),
              height: 50,
              width: 50,
              color: device.isOn ? null : Colors.grey, // optional grey out if off
            ),
            const SizedBox(height: 10),

            // Device name
            Text(
              device.name,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),

            // On/Off toggle
            Switch(
              value: device.isOn,
              onChanged: (_) => onToggle(),
              activeColor: Colors.orangeAccent,
            ),
          ],
        ),
      ),
    );
  }
}
