import 'package:flutter/material.dart';
import 'add_device_screen.dart';
import 'device_card.dart';
import 'device_detail_screen.dart';
import 'models/device.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Device> devices = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Smart Home Dashboard",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.teal,
      ),
      body: Container(
        color: Colors.blueGrey,
        child: GridView.builder(
          padding: const EdgeInsets.all(12),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.9,
          ),
          itemCount: devices.length,
          itemBuilder: (context, index) {
            return DeviceCard(
              device: devices[index],
              onToggle: () {
                setState(() {
                  devices[index].isOn = !devices[index].isOn;
                });
              },
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DeviceDetailsScreen(device: devices[index]),
                  ),
                ).then((_) => setState(() {}));
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newDevice = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddDeviceScreen()),
          );

          if (newDevice != null) {
            setState(() {
              devices.add(newDevice);
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
