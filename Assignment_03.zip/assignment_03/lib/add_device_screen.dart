import 'package:flutter/material.dart';
import '../models/device.dart';

class AddDeviceScreen extends StatefulWidget {
  const AddDeviceScreen({super.key});

  @override
  State<AddDeviceScreen> createState() => _AddDeviceScreenState();
}

class _AddDeviceScreenState extends State<AddDeviceScreen> {
  final nameCtrl = TextEditingController();
  final roomCtrl = TextEditingController();
  String selectedType = "Light";

  // Map device type to icon
  final Map<String, IconData> deviceIcons = {
    "Light": Icons.lightbulb,
    "Fan": Icons.wind_power,
    "AC": Icons.ac_unit,
    "Camera": Icons.videocam,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey,
      appBar: AppBar(
        title: const Text(
          "Add Device",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.teal,
      ),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          margin: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.3),
                spreadRadius: 4,
                blurRadius: 12,
                offset: const Offset(0, 4),
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 🔹 Device Preview Icon
              Icon(
                deviceIcons[selectedType],
                size: 80,
                color: Colors.teal,
              ),
              const SizedBox(height: 20),

              // Device Name
              TextField(
                controller: nameCtrl,
                decoration: InputDecoration(
                  labelText: "Device Name",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 15),

              // Dropdown
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade400),
                ),
                child: DropdownButton<String>(
                  isExpanded: true,
                  underline: const SizedBox(),
                  value: selectedType,
                  items: ["Light", "Fan", "AC", "Camera"]
                      .map((e) => DropdownMenuItem(
                            value: e,
                            child: Text(e),
                          ))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedType = value!;
                    });
                  },
                ),
              ),
              const SizedBox(height: 15),

              // Room Name
              TextField(
                controller: roomCtrl,
                decoration: InputDecoration(
                  labelText: "Room",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // ADD button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    backgroundColor: Colors.teal,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () {
                    if (nameCtrl.text.isEmpty || roomCtrl.text.isEmpty) return;

                    Navigator.pop(
                      context,
                      Device(
                        name: nameCtrl.text,
                        type: selectedType,
                        room: roomCtrl.text,
                      ),
                    );
                  },
                  child: const Text(
                    "Add Device",
                    style: TextStyle(color: Colors.white,fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
