package com.example.assignment_nd;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
