import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Widget Tree LAB 5',
      home: Scaffold(
        appBar: AppBar(
          title:  Text('Widget Tree'),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding:  EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    children:[
                      Container(
                        color: Colors.yellow,
                        height: 40.0,
                        width: 40.0,
                      ),
                      SizedBox(width: 16.0),
                      Expanded(
                        child: Container(
                          color: Colors.amber,
                          height: 40.0,
                        ),
                      ),
                      SizedBox(width: 16.0),
                      Container(
                        color: Colors.brown,
                        height: 40.0,
                        width: 40.0,
                      ),
                    ],
                  ),
                  SizedBox(height: 16.0),
                  Row(
                    children:[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        children:[
                          Container(
                            color: Colors.yellow,
                            height: 60.0,
                            width: 60.0,
                          ),
                          SizedBox(height: 16.0),
                          Container(
                            color: Colors.amber,
                            height: 40.0,
                            width: 40.0,
                          ),
                          SizedBox(height: 16.0),
                          Container(
                            color: Colors.brown,
                            height: 20.0,
                            width: 20.0,
                          ),
                        ],
                      ),
                    ],
                  ),
                  Divider(),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.lightGreen,
                        radius: 100.0,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              height: 100.0,
                              width: 100.0,
                              color: Colors.yellow,
                            ),
                            Container(
                              height: 60.0,
                              width: 60.0,
                              color: Colors.amber,
                            ),
                            Container(
                              height: 40.0,
                              width: 40.0,
                              color: Colors.brown,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Divider(),
                  Text('End of the Line'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}