package com.example.labtask3;

import androidx.annotation.NonNull;

import android.os.BatteryManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {

    private static final String CHANNEL = "com.example.native/channel";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler(
                        (call, result) -> {

                            if (call.method.equals("getPlatformVersion")) {
                                result.success("Android " + Build.VERSION.RELEASE);
                            }

                            else if (call.method.equals("getBatteryLevel")) {
                                int battery = getBatteryLevel();
                                result.success(battery);
                            }

                            else if (call.method.equals("writeTextFile")) {
                                // For now just returning success
                                result.success(true);
                            }

                            else {
                                result.notImplemented();
                            }
                        }
                );
    }

    private int getBatteryLevel() {
        IntentFilter iFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, iFilter);

        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        return (int) ((level / (float) scale) * 100);
    }
}
