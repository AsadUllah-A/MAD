import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  static const platform = MethodChannel('com.example.native/channel');

  String _platformVersion = 'Unknown';
  String _batteryInfo = 'Unknown';
  String _fileWriteResult = 'Not written';

  Future<void> _getPlatformVersion() async {
    try {
      final String result = await platform.invokeMethod('getPlatformVersion');
      setState(() {
        _platformVersion = result;
      });
    } on PlatformException catch (e) {
      setState(() {
        _platformVersion = "Failed: ${e.message}";
      });
    }
  }

  Future<void> _getBatteryLevel() async {
    try {
      final int result = await platform.invokeMethod<int>('getBatteryLevel') ?? -1;
      setState(() {
        _batteryInfo = result >= 0 ? '$result%' : 'Unavailable';
      });
    } on PlatformException catch (e) {
      setState(() {
        _batteryInfo = "Failed: ${e.message}";
      });
    }
  }

  Future<void> _writeTextFile() async {
    try {
      final String text = "This file was written from native code via Flutter method channel.";
      final bool success = await platform.invokeMethod<bool>('writeTextFile', {'text': text}) ?? false;
      setState(() {
        _fileWriteResult = success ? 'File written successfully' : 'File write failed';
      });
    } on PlatformException catch (e) {
      setState(() {
        _fileWriteResult = "Failed: ${e.message}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          backgroundColor: Colors.teal,
          title: const Text(
            'Native Info Hub',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          centerTitle: true,
          elevation: 0,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.teal, Colors.tealAccent]),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: const [
                      Text(
                        'Explore Your Device Info',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Click any button below to fetch the data from native code',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _customButton('Platform', _getPlatformVersion, Colors.deepOrange),
                    _customButton('Battery', _getBatteryLevel, Colors.purple),
                    _customButton('Write File', _writeTextFile, Colors.indigo),
                  ],
                ),
                const SizedBox(height: 30),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 15,
                        offset: Offset(0, 8),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _infoTile('Platform Version', _platformVersion, Icons.android, Colors.teal),
                      Divider(),
                      _infoTile('Battery Level', _batteryInfo, Icons.battery_charging_full, Colors.orange),
                      Divider(),
                      _infoTile('File Status', _fileWriteResult, Icons.file_copy, Colors.blue),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _customButton(String text, VoidCallback onPressed, Color color) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
        backgroundColor: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 6,
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
      ),
    );
  }

  Widget _infoTile(String title, String value, IconData icon, Color iconColor) {
    return Row(
      children: [
        CircleAvatar(
          backgroundColor: iconColor.withOpacity(0.2),
          child: Icon(icon, color: iconColor),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text(value, style: TextStyle(fontSize: 14, color: Colors.black54)),
            ],
          ),
        ),
      ],
    );
  }
}
