import 'package:flutter/material.dart';

class CoursesPage extends StatefulWidget {
  const CoursesPage({super.key});

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade300,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.green.shade800,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 20,
              backgroundImage: AssetImage('assets/pic7.png'),
            ),
            const SizedBox(width: 10),
            const Text(
              'COURSES',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 20,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.info, color: Colors.white),
            onPressed: () {},
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/python.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'PYTHON',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '10 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/c++.jpeg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'C++',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_half, color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '6 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/java.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'JAVA',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '5 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/flutter.jpeg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'FLUTTER',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '15 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/php.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'PHP',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_half, color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '10 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/html.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'HTML',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_half, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '2 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              elevation: 4,
              margin: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Container(
                    height: 90,
                    width: 110,
                    margin: EdgeInsets.all(5.0),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Image(
                        image: AssetImage('assets/css.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'CSS',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Row(
                                children: const [
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_rate_sharp,
                                      color: Colors.amber),
                                  Icon(Icons.star_border, color: Colors.amber),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: const [
                              Icon(Icons.info_outline),
                              SizedBox(width: 10),
                              Icon(Icons.download),
                              Spacer(),
                              Text(
                                '3 Hours',
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
