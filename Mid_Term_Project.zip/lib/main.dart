import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'signin_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: HomeScreen());
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade300,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 60),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Center(
                child: Container(
                  height: 500,
                  width: 300,
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(40),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: CircleAvatar(
                            radius: 70,
                            backgroundImage: AssetImage('assets/pic7.png')),
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Learning Zone',
                        style: TextStyle(
                          fontSize: 30,
                          color: Colors.green.shade800,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Lottie.asset(
                        'assets/Welcome Screen.json',
                        height: 250,
                        repeat: true,
                        reverse: false,
                        animate: true,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 40),
              SizedBox(
                width: 270,
                height: 40,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Login()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade800,
                  ),
                  child: Text(
                    "Let's Go",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
