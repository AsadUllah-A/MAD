package com.example.learning_zone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
