import 'package:flutter/material.dart';
import 'widgets/card_list_widgets.dart';
import 'widgets/grid_widgets.dart';
import 'widgets/stack_widgets.dart';
import 'widgets/sliver_widgets.dart';

void main() {
  runApp(const Ch9DemoApp());
}

class Ch9DemoApp extends StatelessWidget {
  const Ch9DemoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ch9 Scrolling Samples',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  static const List<Widget> _pages = <Widget>[
    ListViewSamplePage(),
    GridViewSamplePage(),
    StackSamplePage(),
    SliversSamplePage(),
  ];

  static const List<String> _titles = <String>[
    'ListView (Cards & Tiles)',
    'GridView',
    'Stack Widgets',
    'CustomScrollView - Slivers',
  ];

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
        elevation: 0.0,
      ),
      body: SafeArea(child: _pages[_selectedIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'List'),
          BottomNavigationBarItem(icon: Icon(Icons.grid_on), label: 'Grid'),
          BottomNavigationBarItem(icon: Icon(Icons.layers), label: 'Stack'),
          BottomNavigationBarItem(icon: Icon(Icons.view_agenda), label: 'Slivers'),
        ],
      ),
    );
  }
}
