import 'package:flutter/material.dart';

class StackSamplePage extends StatelessWidget {
  const StackSamplePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // A ListView to alternate between StackWidget and StackFavoriteWidget as described in the source
    return ListView.builder(
      itemCount: 7,
      itemBuilder: (BuildContext context, int index) {
        if (index.isEven) {
          return const Padding(
            padding: EdgeInsets.all(8.0),
            child: StackWidget(),
          );
        } else {
          return const Padding(
            padding: EdgeInsets.all(8.0),
            child: StackFavoriteWidget(),
          );
        }
      },
    );
  }
}

class StackWidget extends StatelessWidget {
  const StackWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Image(
          image: const AssetImage('assets/tree.jpeg'),
          fit: BoxFit.cover,
          width: double.infinity,
          height: 240.0,
        ),
        Positioned(
          bottom: 10.0,
          left: 10.0,
          child: CircleAvatar(
            radius: 48.0,
            backgroundImage: const AssetImage('assets/lion.jpeg'),
          ),
        ),
        const Positioned(
          bottom: 16.0,
          right: 16.0,
          child: Text(
            'Lion',
            style: TextStyle(
              fontSize: 32.0,
              color: Colors.white70,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}

class StackFavoriteWidget extends StatelessWidget {
  const StackFavoriteWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black87,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Stack(
          children: <Widget>[
            Image(
              image: const AssetImage('assets/dawn.jpeg'),
              fit: BoxFit.cover,
              width: double.infinity,
              height: 220.0,
            ),
            Positioned(
              top: 0.0,
              right: 0.0,
              child: FractionalTranslation(
                translation: const Offset(0.3, -0.3),
                child: CircleAvatar(
                  radius: 24.0,
                  backgroundColor: Colors.white30,
                  child: const Icon(
                    Icons.star,
                    size: 24.0,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 10.0,
              right: 10.0,
              child: CircleAvatar(
                radius: 48.0,
                backgroundImage: const AssetImage('assets/eagle.jpeg'),
              ),
            ),
            const Positioned(
              bottom: 16.0,
              left: 16.0,
              child: Text(
                'Bald Eagle',
                style: TextStyle(
                  fontSize: 32.0,
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
