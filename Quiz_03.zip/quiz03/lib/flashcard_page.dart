import 'package:flutter/material.dart';
import 'flashcard_screen.dart';
import 'add_flashcard.dart';

class FlashcardPage extends StatefulWidget {
  const FlashcardPage({super.key});

  @override
  State<FlashcardPage> createState() => _FlashcardPageState();
}

class _FlashcardPageState extends State<FlashcardPage> {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();

  List<Map<String, String>> flashcards = [
    {'q': 'What is Flutter?', 'a': 'A UI toolkit for building apps with Dart.'},
    {'q': 'What is Dart?', 'a': 'A programming language by Google.'},
    {'q': 'What is StatefulWidget?', 'a': 'A widget that holds mutable state.'},
    {
      'q': 'What is a Future?',
      'a': 'An object representing an async computation.'
    },
  ];

  final ValueNotifier<int> learnedCount = ValueNotifier<int>(0);

  Future<void> _refreshList() async {
    await Future.delayed(const Duration(seconds: 1));
    setState(() {
      flashcards.shuffle();
    });
  }

  void _removeCard(int index) {
    final removed = flashcards[index];
    flashcards.removeAt(index);
    learnedCount.value++; // ✅ updates instantly
    _listKey.currentState!.removeItem(
      index,
      (context, animation) => _buildItem(removed, index, animation),
      duration: const Duration(milliseconds: 400),
    );
  }

  void _addNewCard(Map<String, String> newCard) {
    flashcards.insert(0, newCard);
    _listKey.currentState!
        .insertItem(0, duration: const Duration(milliseconds: 400));
    setState(() {}); // ✅ updates total count in app bar
  }

  Widget _buildItem(
      Map<String, String> card, int index, Animation<double> animation) {
    return SizeTransition(
      sizeFactor: animation,
      child: Dismissible(
        key: Key(card['q']!),
        direction: DismissDirection.endToStart,
        background: Container(
          color: Colors.green,
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          child: const Icon(Icons.check, color: Colors.white, size: 30),
        ),
        onDismissed: (_) => _removeCard(index),
        child: FlashcardWidget(question: card['q']!, answer: card['a']!),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        shape: CircleBorder(),
        child: const Icon(
            Icons.add),
        onPressed: () async {
          final newCard = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddFlashcardPage()),
          );
          if (newCard != null && mounted) {
            _addNewCard(newCard);
          }
        },
      ),
      body: RefreshIndicator(
        onRefresh: _refreshList,
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              expandedHeight: 120,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(color: Colors.deepOrange.shade700),
                // 👇 This part now reacts instantly
                title: ValueListenableBuilder<int>(
                  valueListenable: learnedCount,
                  builder: (context, count, _) {
                    return Text(
                      '$count of ${flashcards.length + count} learned',
                      style: const TextStyle(fontSize: 14),
                    );
                  },
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: AnimatedList(
                key: _listKey,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                initialItemCount: flashcards.length,
                itemBuilder: (context, index, animation) {
                  return _buildItem(flashcards[index], index, animation);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
