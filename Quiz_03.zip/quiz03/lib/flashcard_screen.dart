import 'package:flutter/material.dart';

class FlashcardWidget extends StatefulWidget {
  final String question;
  final String answer;

  const FlashcardWidget(
      {super.key, required this.question, required this.answer});

  @override
  State<FlashcardWidget> createState() => _FlashcardWidgetState();
}

class _FlashcardWidgetState extends State<FlashcardWidget> {
  bool _showAnswer = false;

  void _toggleCard() {
    setState(() {
      _showAnswer = !_showAnswer;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _toggleCard,
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Colors.grey.shade900,
        elevation: 4,
        child: AnimatedCrossFade(
          duration: const Duration(milliseconds: 300),
          crossFadeState: _showAnswer
              ? CrossFadeState.showSecond
              : CrossFadeState.showFirst,
          firstChild: _buildSide(widget.question, Colors.white),
          secondChild: _buildSide(widget.answer, Colors.deepOrange),
        ),
      ),
    );
  }

  Widget _buildSide(String text, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      alignment: Alignment.center,
      height: 150,
      child: Text(
        text,
        style:
            TextStyle(fontSize: 18, color: color, fontWeight: FontWeight.w600),
        textAlign: TextAlign.center,
      ),
    );
  }
}
