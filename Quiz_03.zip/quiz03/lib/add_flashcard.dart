import 'package:flutter/material.dart';

class AddFlashcardPage extends StatefulWidget {
  const AddFlashcardPage({super.key});

  @override
  State<AddFlashcardPage> createState() => _AddFlashcardPageState();
}

class _AddFlashcardPageState extends State<AddFlashcardPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _questionController = TextEditingController();
  final TextEditingController _answerController = TextEditingController();

  void _saveCard() {
    if (_formKey.currentState!.validate()) {
      Navigator.pop(context, {
        'q': _questionController.text.trim(),
        'a': _answerController.text.trim(),
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Flashcard')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _questionController,
                decoration: const InputDecoration(labelText: 'Question',labelStyle: TextStyle(color: Colors.white)),

                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter a question' : null
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _answerController,
                decoration: const InputDecoration(labelText: 'Answer',labelStyle: TextStyle(color: Colors.white)),
                validator: (v) =>
                    v == null || v.isEmpty ? 'Enter an answer' : null,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                style: ButtonStyle(
                ),
                onPressed: _saveCard,
                child: const Text('Add'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
